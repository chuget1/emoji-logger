const path =require("path");
const { CoreClient, } = require("discord-bot-core-client-node");
const { Client, GatewayIntentBits } =require("discord.js");
const { fileURLToPath } =require('url');
const token = process.env.DISCORD_BOT_TOKEN;
  
//const __filename = fileURLToPath(import.meta.url);
//const __dirname = path.dirname(__filename);
const client = new CoreClient({
  token: process.env.DISCORD_BOT_TOKEN,
});
/*const client = new Client({

    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildIntegrations,
      GatewayIntentBits.GuildWebhooks,
      GatewayIntentBits.GuildVoiceStates,
      GatewayIntentBits.GuildPresences,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
    ],
  
});
*/

client.registerBotsIn(path.resolve(__dirname, "bots")).start()