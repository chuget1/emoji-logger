const getDocumentAndSheet = require("../util/getDocumentAndSheet.js");
const backoff = require("../util/backoff");
const rowMapper = require("../util/rowMapper");

const addJoinData = async (sheet, joinData) => {
  await backoff(async () => {
    await sheet.addRow(rowMapper(joinData));
    console.log('Join data added to the sheet.');
  });
};

const updateJoinData = async (row, joinData) => {
  if (row.name === joinData.name) {
    return;
  }

  row.name = joinData.name;
  await backoff(async () => {
    await row.save();
    console.log('Join data updated on the sheet.');
  });
};

module.exports = {
  initializeSheet: async (title, headers) => {
    const { document, sheet } = await getDocumentAndSheet(title);
    if (!document) {
      return;
    }

    if (!sheet) {
      await document.addSheet({
        title,
        headers,
        gridProperties: { columnCount: headers.length },
      });
      console.log(`Sheet "${title}" created.`);
    } else {
      await sheet.setHeaderRow(headers);
      console.log(`Sheet "${title}" already exists. Header row set.`);
    }
  },
  addLogs: async (logs) => {
    const { sheet } = await getDocumentAndSheet("logs");
    if (!sheet) {
      console.error('Logs sheet not found.');
      return;
    }

    try {
      await backoff(async () => {
        await sheet.addRows(logs.map(rowMapper));
        console.log('Logs added to the "logs" sheet.');
      });
    } catch (error) {
      console.error('Error adding logs:', error);
    }
  },
  upsertJoinData: async ({ title, joinData }) => {
    const { sheet } = await getDocumentAndSheet(title);
    if (!sheet) {
      console.error('Sheet not found.');
      return;
    }

    const rows = await sheet.getRows();
    const row = rows.find((row) => row.id === joinData.id);
    if (!row) {
      await addJoinData(sheet, joinData);
      console.log('Join data added to the sheet.');
    } else {
      await updateJoinData(row, joinData);
      console.log('Join data updated on the sheet.');
    }
  },
};
