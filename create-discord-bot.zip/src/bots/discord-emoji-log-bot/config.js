module.exports = {
  sheetId: "10Utn31Gwx7gJ-0AcCEDpFYk4ZWe1mIXDbK9G0aQNW7Q",
  guildChannelMap: {
    "1211812480385290311": {
      text: "1211812480880214068",//general
      channelsToIgnore: [],
    },
  },
};
